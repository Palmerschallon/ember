print('Ember v6 skeleton. Extend me.')
