# Forge v6 — First Light

unzip Forge-v6.zip -d ~/Forge && cd ~/Forge && ./first_light.sh Forge-v6.zip
