print('Use first_light.sh or run muse_service.py + ember_worker.py')
